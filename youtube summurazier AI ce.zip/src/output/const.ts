export const Const = {
  jarvisIframeSelector: '#jarvis-iframe',
};
