export const _ = chrome.i18n.getMessage.bind(chrome.i18n)
